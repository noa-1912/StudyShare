package com.example.demo.model;

public enum ERole {
    ROLE_USER,
    ROLE_CUSTOMER
}
