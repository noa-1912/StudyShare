package com.example.demo.controller;
import java.nio.file.Path;
import java.nio.file.Files;
import com.example.demo.model.Users;
import com.example.demo.security.CustomUserDetails;
import com.example.demo.security.jwt.JwtUtils;
import com.example.demo.service.ImageUtils;
import com.example.demo.service.RoleRepository;
import com.example.demo.service.SuggestionRepository;
import com.example.demo.service.UsersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Paths;
import java.time.LocalDate;

@RestController
@RequestMapping("/api/user")
@CrossOrigin
public class UsersController {
private  UsersRepository usersRepository;
private RoleRepository roleRepository;
private AuthenticationManager authenticationManager;
    private JwtUtils jwtUtils;


@Autowired
public  UsersController(UsersRepository usersRepository,RoleRepository roleRepository, AuthenticationManager authenticationManager,JwtUtils jwtUtils){
    this.usersRepository=usersRepository;
    this.roleRepository=roleRepository;
    this.authenticationManager=authenticationManager;
    this.jwtUtils=jwtUtils;
}

    //התחברות
    @PostMapping("/signin")
    public ResponseEntity<?> signin(@RequestBody Users u){
        Authentication authentication=authenticationManager
                .authenticate(new UsernamePasswordAuthenticationToken(u.getEmail(),u.getPassword()));

        //שומר את האימות
        SecurityContextHolder.getContext().setAuthentication(authentication);
        //CustomUserDetails לוקח את פרטי המשתמש ומכניס אותם
        CustomUserDetails userDetails=(CustomUserDetails)authentication.getPrincipal();

        ResponseCookie jwtCookie=jwtUtils.generateJwtCookie(userDetails);
        Users fullUser = usersRepository.findByEmail(userDetails.getUsername());
        if (fullUser == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found");
        }

        return ResponseEntity.ok().header(HttpHeaders.SET_COOKIE,jwtCookie.toString())
                .body(fullUser);
    }

    //הרשמות
    @PostMapping("/signup")
    public ResponseEntity<Users> signUp(@RequestPart("user") Users user, @RequestPart("image") MultipartFile file) throws IOException {
    //נבדוק ששם משתמש לא קיים
        Users u=usersRepository.findByEmail(user.getEmail());
        if(u!=null)
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);

        ImageUtils.uploadImage(file);
        user.setImagePath(file.getOriginalFilename());
        //לפני שמירצ הסיסמה נעשה הצפנה
        String pass=user.getPassword();//סיסמה לא מוצפנת
        user.setPassword(new BCryptPasswordEncoder().encode(pass));//סיסמה מוצפנת
        user.setDate(LocalDate.now());

        user.getRoles().add(roleRepository.findById((long)1).get());
        usersRepository.save(user);
        return new ResponseEntity<>(user,HttpStatus.CREATED);

    }

    //התנתקות
    @PostMapping("/signout")
    public ResponseEntity<?> signOut(){
        ResponseCookie cookie=jwtUtils.getCleanJwtCookie();
        return ResponseEntity.ok().header(HttpHeaders.SET_COOKIE,cookie.toString())
                .body("you've been signed out!");
    }
    @GetMapping("/image/{filename:.+}")
    public ResponseEntity<byte[]> getUserImage(@PathVariable String filename) {
        try {
            // אותו הנתיב שבו נשמרות התמונות
            Path imagePath = Paths.get(System.getProperty("user.dir") + "\\images\\" + filename);
            byte[] imageBytes = Files.readAllBytes(imagePath);

            return ResponseEntity.ok()
                    .header("Content-Type", Files.probeContentType(imagePath))
                    .body(imageBytes);
        } catch (IOException e) {
            System.out.println("❌ שגיאה בקריאת תמונת משתמש: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }

}
