package com.example.demo.dto;

public class SolutionsDTO extends SuggestionDTO {

    private double avg;

    public double getAvg() {
        return avg;
    }

    public void setAvg(double avg) {
        this.avg = avg;
    }
}
