package com.example.demo.dto;

public class SolutionsDTO extends SuggestionDTO {

    private double avgRating;

    public double getAvgRating() {
        return avgRating;
    }

    public void setAvgRating(double avgRating) {
        this.avgRating = avgRating;
    }
}
