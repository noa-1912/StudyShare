package com.example.demo.service;

import com.example.demo.dto.SolutionsDTO;
import com.example.demo.model.Solutions;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface SolutionsMapper extends SuggesionMapper{

    // ממיר Entity (Solutions) ל־DTO (SolutionsDTO)
    SolutionsDTO solutionsDto(Solutions s);



}


