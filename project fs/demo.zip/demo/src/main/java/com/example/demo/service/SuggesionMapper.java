package com.example.demo.service;

import com.example.demo.dto.SuggestionDTO;
import com.example.demo.model.Suggestion;
import org.mapstruct.Mapper;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Base64;

@Mapper(componentModel = "spring")
public interface SuggesionMapper {


    default SuggestionDTO suggestionDto(Suggestion s) throws IOException {
        SuggestionDTO suggestionDTO=new SuggestionDTO();

        suggestionDTO.setId(s.getId());
        suggestionDTO.setContent(s.getContent());
        suggestionDTO.setPage(s.getPage());
        suggestionDTO.setExercise(s.getExercise());
        suggestionDTO.setSection(s.getSection());
        suggestionDTO.setSubSection(s.getSubSection());
        suggestionDTO.setUploadDate(s.getUploadDate());
       // suggestionDTO.setImagePath(s.getImagePath());

        //החזרת התמונה
        Path filename = Paths.get(s.getImagePath());//לוקח את נתיב התמונה
        byte[] byteImages = Files.readAllBytes(filename);//מעביר את התמונה למערך ביטים
        suggestionDTO.setImage(Base64.getEncoder().encodeToString(byteImages));

        return suggestionDTO;
    }

}
