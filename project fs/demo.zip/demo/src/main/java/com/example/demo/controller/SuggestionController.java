package com.example.demo.controller;


import com.example.demo.dto.SuggestionDTO;
import com.example.demo.model.Suggestion;
import com.example.demo.service.SuggesionMapper;
import com.example.demo.service.SuggestionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@RequestMapping("api/suggesion")
@RestController
@CrossOrigin
public class SuggestionController {

    SuggestionRepository suggestionRepository;
    SuggesionMapper suggesionMapper;
    //מחזיר את המיקום של הפרויקט הספציפי
    private static String UPLOAD_DIRECTORY = System.getProperty("user.dir") + "\\images\\";

    @Autowired//Spring “מכניס” עבורך את האובייקט הדרוש מבלי שתצטרכי ליצור אותו בעצמך עם new.
    public SuggestionController(SuggestionRepository suggestionRepository, SuggesionMapper suggesionMapper) {
        this.suggestionRepository = suggestionRepository;
        this.suggesionMapper = suggesionMapper;
    }

    @GetMapping("/getSuggestion/{id}")
    public ResponseEntity<SuggestionDTO> get(@PathVariable long id) throws IOException {
        Suggestion s = suggestionRepository.findById(id).get();
        if (s != null)
            return new ResponseEntity<>(suggesionMapper.suggestionDto(s), HttpStatus.OK);
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }


    //העלאת פתרון חדש עם בחירת תמונה מהמחשב
    @PostMapping("/uploadSaggestion")
    public ResponseEntity<Suggestion> uploadSaggestionWithImage(
            @RequestPart("image") MultipartFile file,
            @RequestPart("suggestion") Suggestion s) {

        try {
            //כאן נשמר התמונה כולל הסיומת שלו
            String filePath = UPLOAD_DIRECTORY + file.getOriginalFilename();
            Path fileName = Paths.get(filePath);
            Files.write(fileName, file.getBytes());
            s.setImagePath(filePath);
            Suggestion suggestion = suggestionRepository.save(s);
            return new ResponseEntity<>(suggestion, HttpStatus.CREATED);

        } catch (IOException e) {
            System.out.println(e);
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
